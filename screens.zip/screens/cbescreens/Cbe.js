import * as React from 'react';
import {
  Pressable,
  Image,
  Text,
  ScrollView,
  SafeAreaView,
  View,
  useWindowDimensions,
  StyleSheet,
} from 'react-native';
import CbeprofileStack from './Cbeprofile';
import Icon from 'react-native-vector-icons/Ionicons';
import Icontypo from 'react-native-vector-icons/Entypo';
import {createStackNavigator} from '@react-navigation/stack';

import Cbebeneficary from './Cbebeneficary';
import Cbeutility from './Cbeutility';
import Cbetransfer from './Cbetransfer';
import Cbetopup from './Cbetopup';

const Stack = createStackNavigator();
const useState = React.useState;
function Cbe({navigation}) {
  let {height, width} = useWindowDimensions();
  function calcWidth(percent) {
    let per = percent / 100;
    return Number(width * per);
  }
  function calcHeight(percent) {
    let per = percent / 100;
    return per * height;
  }

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
    },
    subcontainer: {
      marginBottom: 20,
    },
    image1: {
      width: Number(width) * 0.6,
      height: Number(height) * 0.4,
      marginTop: '5%',
      alignSelf: 'center',
    },
    rect: {
      marginTop: calcWidth(6),
      width: calcWidth(90),
      height: calcHeight(9),
      borderColor: '#2196F3',
      borderWidth: 2,
      backgroundColor: '#fff',
      shadowOffset: {
        width: 13,
        height: 13,
      },
      elevation: 10,
      alignSelf: 'center',
      shadowOpacity: 1,
      shadowRadius: 0,
      borderRadius: 19,
    },

    text: {
      fontFamily: 'roboto-regular',
      color: 'rgba(0, 0, 0, 0.6)',
      fontSize: calcWidth(6),
      textAlign: 'center',
      marginTop: calcHeight(-5.2),
    },

    icon: {
      fontSize: calcWidth(6),
      color: '#2196F3',
      marginTop: calcHeight(2),
      marginLeft: calcWidth(10),
    },
  });
  const pressStyle = StyleSheet.create({
    rect: {
      marginTop: calcWidth(5.2),
      width: calcWidth(91),
      height: calcHeight(9.5),
      borderColor: 'rgba(0 , 0,0,0.5)',
      borderWidth: 2,
      backgroundColor: '#fff',
      shadowOffset: {
        width: 13,
        height: 13,
      },
      elevation: 10,
      alignSelf: 'center',
      shadowOpacity: 1,
      shadowRadius: 0,
      borderRadius: 19,
    },
    text: {
      fontFamily: 'roboto-regular',
      color: 'rgba(0, 0, 0, 0.6)',
      fontSize: calcWidth(7),
      textAlign: 'center',
      marginTop: calcHeight(-5.2),
    },

    icon: {
      fontSize: calcWidth(6),
      color: '#2196F3',
      marginTop: calcHeight(2),
      marginLeft: calcWidth(10),
    },
  });
  const [isPressed1, setPressed1] = useState(false);
  const [isPressed2, setPressed2] = useState(false);
  const [isPressed3, setPressed3] = useState(false);
  const [isPressed4, setPressed4] = useState(false);
  const [isPressed5, setPressed5] = useState(false);
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.subcontainer}>
          <Image
            source={require('./../../src/img/cbe.png')}
            resizeMode="contain"
            style={styles.image1}
          />
          <Pressable
            style={isPressed1 ? pressStyle.rect : styles.rect}
            onPress={() => {
              requestAnimationFrame(() => navigation.navigate('Cbetransfer'));
            }}
            onPressIn={() => setPressed1(true)}
            onPressOut={() => setPressed1(false)}>
            <Icontypo
              name="swap"
              style={isPressed1 ? pressStyle.icon : styles.icon}
            />
            <Text style={isPressed1 ? pressStyle.text : styles.text}>
              Transfer
            </Text>
          </Pressable>
          <Pressable
            onPress={() => {
              requestAnimationFrame(() => navigation.navigate('Cbetopup'));
            }}
            onPressIn={() => setPressed2(true)}
            onPressOut={() => setPressed2(false)}>
            <View style={isPressed2 ? pressStyle.rect : styles.rect}>
              <Icontypo
                name="mobile"
                style={isPressed2 ? pressStyle.icon : styles.icon}
              />
              <Text style={isPressed2 ? pressStyle.text : styles.text}>
                Top Up
              </Text>
            </View>
          </Pressable>
          <Pressable
            onPressIn={() => setPressed3(true)}
            onPressOut={() => setPressed3(false)}
            onPress={() => {
              requestAnimationFrame(() => navigation.navigate('Cbebeneficary'));
            }}>
            <View style={isPressed3 ? pressStyle.rect : styles.rect}>
              <Icon
                name="md-people"
                style={isPressed3 ? pressStyle.icon : styles.icon}
              />
              <Text style={isPressed3 ? pressStyle.text : styles.text}>
                People
              </Text>
            </View>
          </Pressable>
          <Pressable
            onPressIn={() => setPressed4(true)}
            onPressOut={() => setPressed4(false)}
            onPress={() => {
              requestAnimationFrame(() => navigation.navigate('Cbeutility'));
            }}>
            <View style={isPressed4 ? pressStyle.rect : styles.rect}>
              <Icon
                name="ios-home"
                style={isPressed4 ? pressStyle.icon : styles.icon}
              />
              <Text style={isPressed4 ? pressStyle.text : styles.text}>
                Utilities
              </Text>
            </View>
          </Pressable>
          <Pressable
            onPressIn={() => setPressed5(true)}
            onPressOut={() => setPressed5(false)}
            onPress={() => {
              requestAnimationFrame(() =>
                navigation.navigate('Cbeprofilestack'),
              );
            }}>
            <View style={isPressed5 ? pressStyle.rect : styles.rect}>
              <Icon
                name="ios-home"
                style={isPressed5 ? pressStyle.icon : styles.icon}
              />
              <Text style={isPressed5 ? pressStyle.text : styles.text}>
                Profile
              </Text>
            </View>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function CbeStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerTintColor: 'white',
        headerStyle: {backgroundColor: '#2196F3'},
      }}>
      <Stack.Screen name="Cbehome" options={{title: 'CBE'}} component={Cbe} />
      <Stack.Screen
        name="Cbetopup"
        options={{title: 'CBE TopUp'}}
        component={Cbetopup}
      />
      <Stack.Screen
        options={{headerShown: false}}
        name="Cbetransfer"
        component={Cbetransfer}
      />
      <Stack.Screen
        options={{headerShown: false}}
        name="Cbeutility"
        component={Cbeutility}
      />
      <Stack.Screen
        options={{headerShown: false}}
        name="Cbeprofilestack"
        component={CbeprofileStack}
      />
      <Stack.Screen
        options={{title: 'Beneficiary'}}
        name="Cbebeneficary"
        component={Cbebeneficary}
      />
    </Stack.Navigator>
  );
}
export default CbeStack;
